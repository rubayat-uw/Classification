import numpy as np
import pandas as pd
import seaborn as sns; sns.set(font_scale=1.2)
import matplotlib.pyplot as plt

data1=pd.read_csv('bank-additional.csv')
data2=data1.replace("unknown",np.NaN)
full_data=data2.dropna(axis=0,thresh=20)
target=full_data[['y']].copy()
data=full_data.drop(['y'], axis=1)


#data preprocessing
data['marital'].fillna(value='married',inplace=True)

data['job'] = np.where(data.job =='admin.', 'admin',data.job)

#data['education'] = np.where((data.job =='admin.') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='admin') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='blue-collar') & (data.education.isnull() ), 'basic.9y',data.education)
data['education'] = np.where((data.job =='entrepreneur') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='housemaid') & (data.education.isnull() ), 'basic.4y',data.education)
data['education'] = np.where((data.job =='management') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='retired') & (data.education.isnull() ), 'basic.4y',data.education)
data['education'] = np.where((data.job =='self-employed') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='services') & (data.education.isnull() ), 'high.school',data.education)
data['education'] = np.where((data.job =='student') & (data.education.isnull() ), 'high.school',data.education)
data['education'] = np.where((data.job =='technician') & (data.education.isnull() ), 'professional.course',data.education)
data['education'] = np.where((data.job =='unemployed') & (data.education.isnull() ), 'university.degree',data.education)

data['default'] = np.where(data.default.isnull(), 'no',data.default)

data=data.dropna(axis=0)

##one hot Encode
bot_encode=pd.get_dummies(data,drop_first=True)
from sklearn import preprocessing   
label_encoder = preprocessing.LabelEncoder()
target["y"] = label_encoder.fit_transform(target["y"])  

#plot the outliers
import seaborn as sns

i=['age', 'duration', 'campaign', 'pdays', 'previous', 'emp.var.rate',
       'cons.price.idx', 'cons.conf.idx', 'euribor3m', 'nr.employed']

for j in i:
    plt.subplot(212)
    plt.xlim(full_data[j].min(), full_data[j].max()*1.1)
    sns.boxplot(x=full_data[j])
    plt.show()
