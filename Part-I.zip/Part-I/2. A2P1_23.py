import numpy as np
import pandas as pd
import seaborn as sns; sns.set(font_scale=1.2)
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_score
import warnings
warnings.filterwarnings("ignore")

data1=pd.read_csv('bank-additional.csv')
data2=data1.replace("unknown",np.NaN)
data=data2.dropna(axis=0,thresh=20)

#data preprocessing
data['marital'].fillna(value='married',inplace=True)

data['job'] = np.where(data.job =='admin.', 'admin',data.job)

#data['education'] = np.where((data.job =='admin.') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='admin') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='blue-collar') & (data.education.isnull() ), 'basic.9y',data.education)
data['education'] = np.where((data.job =='entrepreneur') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='housemaid') & (data.education.isnull() ), 'basic.4y',data.education)
data['education'] = np.where((data.job =='management') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='retired') & (data.education.isnull() ), 'basic.4y',data.education)
data['education'] = np.where((data.job =='self-employed') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='services') & (data.education.isnull() ), 'high.school',data.education)
data['education'] = np.where((data.job =='student') & (data.education.isnull() ), 'high.school',data.education)
data['education'] = np.where((data.job =='technician') & (data.education.isnull() ), 'professional.course',data.education)
data['education'] = np.where((data.job =='unemployed') & (data.education.isnull() ), 'university.degree',data.education)

data['default'] = np.where(data.default.isnull(), 'no',data.default)

data=data.dropna(axis=0)

target=data[['y']].copy()
data=data.drop(['y'], axis=1)

##one hot Encode
bot_encode=pd.get_dummies(data,drop_first=True)
from sklearn import preprocessing   
label_encoder = preprocessing.LabelEncoder()
target["y"] = label_encoder.fit_transform(target["y"])  

##split
from sklearn.cross_validation import train_test_split
import sklearn.preprocessing as  mm
X_train,X_test,y_train,y_test=train_test_split(bot_encode,target,test_size=0.30,random_state=123)
sc=mm.StandardScaler()
X_train=sc.fit_transform(X_train)
X_test=sc.fit_transform(X_test)

##Decision Tree classifier
from sklearn import tree
j=[]
s=[]

for i in range(1,21, 1):
    j.append(i) 
    clf_dT = tree.DecisionTreeClassifier(max_depth=i)
    scores = cross_val_score(clf_dT, X_train, y_train, cv=5)
    s.append(scores.mean())
max_index=np.argmax(s)
print('Optimum depth for decision tree',j[max_index])
plt.figure()
plt.plot(j,s)
plt.ylabel('Classification Accuracy')
plt.xlabel('max_depth')

##Random Forest
from sklearn.ensemble import RandomForestClassifier

j=[]
s_rf=[]

for i in range(1,50,1):
    j.append(i) 
    clf_rf = RandomForestClassifier(n_estimators=i,min_samples_leaf=1,)
    scores_rf = cross_val_score(clf_rf, X_train, y_train, cv=5)
    s_rf.append(scores_rf.mean())

max_index=np.argmax(s_rf)
print('Optimum no of trees for Random forest',j[max_index])
plt.figure()
plt.plot(j,s_rf)
plt.ylabel('Classification Accuracy')
plt.xlabel('no of trees')
    
#NN 
from sklearn.neural_network import MLPClassifier

j=[]
s_nn=[]
for i in range(1,11,1):
    j.append(i) 
    clf_nn = MLPClassifier(hidden_layer_sizes=(i))
    scores_nn = cross_val_score(clf_nn, X_train, y_train, cv=5)
    s_nn.append(scores_nn.mean())

max_index=np.argmax(s_nn)
print('Optimum no of hidden layer',j[max_index])
plt.figure()
plt.plot(j,s_nn)
plt.ylabel('Classification Accuracy')
plt.xlabel('no of hidden layer')


 
    
    
