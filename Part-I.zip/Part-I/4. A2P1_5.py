import numpy as np
import pandas as pd
from sklearn import svm
# use seaborn plotting defaults
import seaborn as sns; sns.set(font_scale=1.2)
import sklearn.preprocessing as  mm
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.cross_validation import train_test_split
full_data=pd.read_csv('bank-additional.csv')
#target=pd.DataFrame()
target=full_data[['y']].copy()
data=full_data.drop(['y'], axis=1)
cols=('job', 'marital', 'education', 'default', 'housing', 'loan',
       'contact', 'month', 'day_of_week', 'poutcome')

# Initialize label encoder
for c in cols:
    lbl = LabelEncoder() 
    lbl.fit(list(data[c].values)) 
    data[c] = lbl.transform(list(data[c].values))
from sklearn import preprocessing   
label_encoder = preprocessing.LabelEncoder()
target["y"] = label_encoder.fit_transform(target["y"])    
  
##split

X_train,X_test,y_train,y_test=train_test_split(data,target,test_size=0.30,random_state=123)
sc=mm.StandardScaler()
X_train=sc.fit_transform(X_train)
X_test=sc.fit_transform(X_test)

import matplotlib.pyplot as plt
from mlxtend.evaluate import confusion_matrix
from sklearn import tree

from sklearn.metrics import accuracy_score
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from mlxtend.plotting import plot_confusion_matrix
names = ["Decision Tree", "Random Forest", "Neural Network"]
classifiers = [DecisionTreeClassifier(),
    RandomForestClassifier(max_depth=5, n_estimators=10, max_features=1),
    MLPClassifier(alpha=1)]
label=['FN','FP','TN','TP']

index = np.arange(2)
accuracy= pd.DataFrame()
acc=[]

i=[0,1,2]
ii=[0,0,0]
bar_width=0.35
for name,clf,k in zip(names,classifiers,i):
    clf.fit(X_train, y_train)
    y_pred_1=clf.predict(X_test)
    y_pred=pd.DataFrame(y_pred_1)
    cm = confusion_matrix(y_test,y_pred)
    fig, ax = plot_confusion_matrix(conf_mat=cm)
    ax.set_title(name)
    plt.show()
    print("Accuracy of",name, accuracy_score(y_pred,y_test))
    accuracy.loc[0,k]=accuracy_score(y_pred,y_test)
    acc1=accuracy_score(y_pred,y_test)
#    plt.hist(acc)
    
    fig, ax = plt.subplots()
    rects1 = ax.bar(index, cm[0],bar_width)
    rects2 = ax.bar(index + bar_width, cm[1], bar_width,
                 color='r')
    ax = plt.gca()
    pos = []
    for bar in ax.patches:
        pos.append(bar.get_x()+bar.get_width()/2.)
    ax.set_xticks(pos,minor=True)
    lab = []
    for i in range(0,len(pos)):
        l = label[i]
        lab.append(l)
    ax.set_xticklabels(lab,minor=True)
    ax.tick_params(axis='x', which='major', pad=15, size=0,bottom='off', top='off', labelbottom='off')
    plt.setp(ax.get_xticklabels(), rotation=0)
    ax.set_title(name)
    plt.legend()

    plt.tight_layout()
    
accuracy.columns=["DT","RF","NN"]
ax = accuracy[['DT','RF',"NN"]].plot(kind='bar', title ="Accuracy Bar", legend=True, fontsize=12)
ax.set_xlabel("accuracy rate", fontsize=12)













