import numpy as np
import pandas as pd
import seaborn as sns; sns.set(font_scale=1.2)
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings("ignore")

from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm


data1=pd.read_csv('bank-additional.csv')
data2=data1.replace("unknown",np.NaN)
data=data2.dropna(axis=0,thresh=20)

#data preprocessing
data['marital'].fillna(value='married',inplace=True)

data['job'] = np.where(data.job =='admin.', 'admin',data.job)

#data['education'] = np.where((data.job =='admin.') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='admin') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='blue-collar') & (data.education.isnull() ), 'basic.9y',data.education)
data['education'] = np.where((data.job =='entrepreneur') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='housemaid') & (data.education.isnull() ), 'basic.4y',data.education)
data['education'] = np.where((data.job =='management') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='retired') & (data.education.isnull() ), 'basic.4y',data.education)
data['education'] = np.where((data.job =='self-employed') & (data.education.isnull() ), 'university.degree',data.education)
data['education'] = np.where((data.job =='services') & (data.education.isnull() ), 'high.school',data.education)
data['education'] = np.where((data.job =='student') & (data.education.isnull() ), 'high.school',data.education)
data['education'] = np.where((data.job =='technician') & (data.education.isnull() ), 'professional.course',data.education)
data['education'] = np.where((data.job =='unemployed') & (data.education.isnull() ), 'university.degree',data.education)

data['default'] = np.where(data.default.isnull(), 'no',data.default)

data=data.dropna(axis=0)

target=data[['y']].copy()
data=data.drop(['y'], axis=1)

##one hot Encode
bot_encode=pd.get_dummies(data,drop_first=True)
from sklearn import preprocessing   
label_encoder = preprocessing.LabelEncoder()
target["y"] = label_encoder.fit_transform(target["y"])  

##split
from sklearn.cross_validation import train_test_split
import sklearn.preprocessing as  mm
X_train,X_test,y_train,y_test=train_test_split(bot_encode,target,test_size=0.30,random_state=123)
sc=mm.StandardScaler()
X_train=sc.fit_transform(X_train)
X_test=sc.fit_transform(X_test)

##Decision Tree classifier
from sklearn import tree

clf = tree.DecisionTreeClassifier(max_depth=5)
clf = clf.fit(X_train,y_train)
y_pred_dtc=clf.predict(X_test)
y_pred=pd.DataFrame(y_pred_dtc)
y_pred.columns = ['y_pred']
print('Decision Tree Accuraccy:',accuracy_score(y_test, y_pred))

##Random Forest
from sklearn.ensemble import RandomForestClassifier
rfclf = RandomForestClassifier(n_estimators=20)
rfclf = rfclf.fit(X_train,y_train)
y_pred_rf=rfclf.predict(X_test)
y_pred_rf1=pd.DataFrame(y_pred_rf)
y_pred_rf1.columns = ['y_pred']
print ('Random Forest Accuraccy:',accuracy_score(y_pred_rf,y_test))

#NN 
from sklearn.neural_network import MLPClassifier

mlp_clf = MLPClassifier(hidden_layer_sizes=(2))
mlp_clf=mlp_clf.fit(X_train, y_train)
y_pred_mlp=mlp_clf.predict(X_test)
y_pred_mlp1=pd.DataFrame(y_pred_mlp)
y_pred_mlp1.columns = ['y_pred']
print('Nural Network Accuraccy:',accuracy_score(y_pred_mlp1,y_test) )

#SVM
svm = svm.SVC(kernel='linear')
svm.fit(X_train, y_train)
y_predict_svm=svm.predict(X_test)
accuracy_svm=accuracy_score(y_test, y_predict_svm,normalize=True)*100
print('SVM Accuraccy:',accuracy_svm)

#KNN
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
y_predict_knn=knn.predict(X_test)
acuracy_knn=accuracy_score(y_test, y_predict_knn,normalize=True)*100
print('KNN Accuraccy:',acuracy_knn)
    
    
