import numpy as np
import pandas as pd
import seaborn as sns; sns.set(font_scale=1.2)
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.cross_validation import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

from itertools import chain
import warnings
warnings.filterwarnings("ignore")
from sklearn.utils import resample
data1=pd.read_csv('bank-additional.csv')
#data2=data1.replace("unknown",np.NaN)
#data=data2.dropna(axis=0,thresh=20)
data1 = data1.select_dtypes(include=['object']).copy()
data1=pd.get_dummies(data1, columns=["job", "marital", "education", "default", "housing", "loan", "contact",
       "month", "day_of_week", "poutcome"], prefix=["job", "marital", "education", "default", "housing", "loan", "contact",
       "month", "day_of_week", "poutcome"])
data1['y'] = [1 if y=='yes' else 0 for y in data1.y]
print(data1['y'].value_counts())





# Separate input features (X) and target variable (y)
y = data1.y
X = data1.drop('y', axis=1)
# Train model
clf_0 = LogisticRegression().fit(X, y)
 # Predict on training set
pred_y_0 = clf_0.predict(X)
#accuracy?
print( accuracy_score(pred_y_0, y) )

# Separate majority and minority classes
df_majority = data1[data1.y==0]
df_minority = data1[data1.y==1]
 
# Upsample minority class
df_minority_upsampled = resample(df_minority, 
                                 replace=True,     # sample with replacement
                                 n_samples=3668,    # to match majority class
                                 random_state=123) # reproducible results
 
# Combine majority class with upsampled minority class
df_upsampled = pd.concat([df_majority, df_minority_upsampled])
print(df_upsampled.y.value_counts())


#Train model on downsampled datasetPython

# Separate input features (X) and target variable (y)
y = df_upsampled.y
X = df_upsampled.drop('y', axis=1)
# Train model
clf_1 = LogisticRegression().fit(X, y)
 # Predict on training set
pred_y_1 = clf_1.predict(X)
# accuracy?
print( accuracy_score(pred_y_1,y) )
 
# Downsample majority class
df_majority_downsampled = resample(df_majority, 
                                 replace=False,    # sample without replacement
                                 n_samples=451,     # to match minority class
                                 random_state=123) # reproducible results
 
# Combine minority class with downsampled majority class
df_downsampled = pd.concat([df_majority_downsampled, df_minority])
 # Display new class counts
print(df_downsampled.y.value_counts())
# Separate input features (X) and target variable (y)
y = df_downsampled.y
X = df_downsampled.drop('y', axis=1)
# Train model
clf_2 = LogisticRegression().fit(X, y)
 # Predict on training set
pred_y_2 = clf_2.predict(X)
#accuracy?
print( accuracy_score(y, pred_y_2) )
