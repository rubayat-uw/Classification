import sklearn.preprocessing as  mm
import scipy.io
import pandas as pd
from sklearn.cross_validation import train_test_split
from sklearn.metrics import accuracy_score

#Data loading
data = scipy.io.loadmat('DataDNA.mat')
s=data.get('fea')
X = pd.DataFrame(s)
y=data.get('gnd')

#split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.30,random_state=123)
sc=mm.StandardScaler()
X_train=sc.fit_transform(X_train)
X_test=sc.fit_transform(X_test)

##SVM
from sklearn import svm
svm_clf = svm.SVC(C=5,gamma=0.02,kernel='rbf')
svm_clf.fit(X_train, y_train)
y_pred_svm=svm_clf.predict(X_test)
print('Accuracy_SVM:',accuracy_score(y_pred_svm,y_test) )

#KNN
from sklearn.neighbors import KNeighborsClassifier
kn_clf = KNeighborsClassifier(n_neighbors=15)
kn_clf.fit(X_train, y_train)
y_pred_kn=kn_clf.predict(X_test)
print('Accuracy_KNN:', accuracy_score(y_pred_kn,y_test) )

##Random forest Classifier
from sklearn.ensemble import RandomForestClassifier
rfclf = RandomForestClassifier(n_estimators=100,min_samples_leaf=1,)
rfclf = rfclf.fit(X_train,y_train)
y_pred_rf=rfclf.predict(X_test)
print('Accuracy_RF:', accuracy_score(y_pred_rf,y_test) )

#NN
from sklearn.neural_network import MLPClassifier
mlp_clf = MLPClassifier(hidden_layer_sizes=(10),max_iter=500,activation="tanh",solver='sgd')
mlp_clf=mlp_clf.fit(X_train, y_train)
y_pred_mlp=mlp_clf.predict(X_test)
print('Accuracy_NN:',accuracy_score(y_pred_mlp,y_test) )