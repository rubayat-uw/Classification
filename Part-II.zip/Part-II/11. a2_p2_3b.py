import sklearn.preprocessing as  mm
import scipy.io
import pandas as pd
import numpy as np
from sklearn.cross_validation import train_test_split

###Data Loading
data = scipy.io.loadmat('DataDNA.mat')
s=data.get('fea')
X = pd.DataFrame(s)
y=data.get('gnd')

###split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.30,random_state=123)
sc=mm.StandardScaler()
X_train=sc.fit_transform(X_train)
X_test=sc.fit_transform(X_test)

###Random forest Classifier
sample_leaf_options = [1,5,10,50,100,200,500]
from sklearn.ensemble import RandomForestClassifier

from operator import itemgetter

## Utility function to report best scores
def report(grid_scores, n_top):
    top_scores = sorted(grid_scores, key=itemgetter(1), reverse=True)[:n_top]
    for i, score in enumerate(top_scores):
        print("Model with rank: {0}".format(i + 1))
        print("Mean validation score: {0:.4f})".format(
              score.mean_validation_score,
              np.std(score.cv_validation_scores)))
        print("Parameters: {0}".format(score.parameters))
        print("")
from sklearn.model_selection import GridSearchCV

###random forest
param_grid1 = {"n_estimators": [100,200,300],"max_depth" :[10,20,30],
              "bootstrap":[True,False]}
rfclf = RandomForestClassifier()
grid_search = GridSearchCV(rfclf, param_grid=param_grid1)
grid_search.fit(X_train, y_train)

#from operator import itemgetter
report(grid_search.grid_scores_, 6)
print(grid_search.best_score_)

####NN
from sklearn.neural_network import MLPClassifier

mlp_clf = MLPClassifier()
mlp_clf=mlp_clf.fit(X_train, y_train)
param_grid2 = {"activation": ["relu","tanh","logistic","identity"],
               "hidden_layer_sizes": [(100,100,100), (13,13,13), (100,100,100),(100)],
              "solver":["lbfgs", "sgd", "adam"]}
nnclf = MLPClassifier()
grid_search = GridSearchCV(nnclf, param_grid=param_grid2)
grid_search.fit(X_train, y_train)

report(grid_search.grid_scores_, 6)