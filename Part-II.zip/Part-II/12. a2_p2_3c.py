from sklearn.preprocessing import Imputer
import sklearn.preprocessing as  mm
import scipy.io
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

data = scipy.io.loadmat('C:\\UWaterloo\Semester\Winter 2018\ECE 657A\Assignment 2\DataDNA.mat')
s=data.get('fea')
X = pd.DataFrame(s)
y=data.get('gnd')
#y = gnd 
#split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.30,random_state=123)
sc=mm.StandardScaler()
X_train=sc.fit_transform(X_train)
X_test=sc.fit_transform(X_test)
accuracy_value={}
accuracy_rate=[]
precision=[]
recall=[]
f_score=[]
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
import time
names = ["Nearest Neighbors", "RBF SVM", "Random Forest", "Neural Net"]

accuracy_rate=np.zeros((20,4))
precision=np.zeros((20,4))
recall=np.zeros((20,4))
f_score=np.zeros((20,4))
classifiers = [
    KNeighborsClassifier(15),
    SVC(kernel="rbf", C=1),
    RandomForestClassifier(max_depth=5, n_estimators=10, max_features=1),
    MLPClassifier(alpha=1)]
training_time= pd.DataFrame()
classification_time=pd.DataFrame()
for j in range(0,20,1):
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.30)
#    sc=mm.StandardScaler()
#    X_train=sc.fit_transform(X_train)
#    X_test=sc.fit_transform(X_test)
    for k in range (0,4,1):
        start = time.time()
        classifiers[k].fit(X_train, y_train)
        training_time.loc[j,k]="{:.2f} ".format(time.time() - start)
        start = time.time()
        y_pred_svm=classifiers[k].predict(X_test)
        classification_time.loc[j,k]="{:.2f} ".format(time.time() - start)
        accuracy_rate[j,k]=(accuracy_score(y_test, y_pred_svm,normalize=True))
        precision[j,k]=(precision_score(y_test, y_pred_svm))
        recall[j,k]=(recall_score(y_test, y_pred_svm))
        f_score[j,k]=(f1_score(y_test, y_pred_svm))
       

training_time.columns= ["Nearest Neighbors", "RBF SVM", "Random Forest", "Neural Net"] 

classification_time.columns= ["Nearest Neighbors", "RBF SVM", "Random Forest", "Neural Net"]       


      
accuracy_rate = pd.DataFrame(accuracy_rate)
accuracy_rate.columns = ['KNN_Accuracy', 'RBF_SVM_Accuracy', 'RandomForest_Accuracy', 'NN_Accuracy']
accuracy_rate.loc['mean']=accuracy_rate.mean()
accuracy_rate.loc['std']=accuracy_rate.std()

####        
precision = pd.DataFrame(precision)
precision.columns = ['KNN_precision', 'RBF_SVM_precision', 'RandomForest_precision', 'NN_precision']
precision.loc['mean']=precision.mean()
precision.loc['std']=precision.std()

######
recall = pd.DataFrame(recall)
recall.columns = ['KNN_recall', 'RBF_SVM_recall', 'RandomForest_recall', 'NN_recall']
recall.loc['mean']=recall.mean()
recall.loc['std']=recall.std()

#######
f_score = pd.DataFrame(f_score)
f_score.columns = ['KNN_f_score', 'RBF_SVM_f_score', 'RandomForest_f_scorey', 'NN_f_score']
f_score.loc['mean']=f_score.mean()
f_score.loc['std']=f_score.std()
X12=pd.concat([accuracy_rate,precision,recall,f_score],axis=1)

mean_std_accuracy_rate=accuracy_rate.drop(accuracy_rate.index[0:20])
mean_std_precision=precision.drop(precision.index[0:20])
mean_std_recall=recall.drop(recall.index[0:20])
mean_std_fscore=f_score.drop(f_score.index[0:20])
