from sklearn.preprocessing import Imputer
import sklearn.preprocessing as  mm
import scipy.io
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.metrics import accuracy_score

data = scipy.io.loadmat('DataDNA.mat')
s=data.get('fea')
X = pd.DataFrame(s)
y=data.get('gnd')


from sklearn.ensemble import ExtraTreesClassifier
forest = ExtraTreesClassifier()
forest.fit(X, y)
importances = forest.feature_importances_
std = np.std([tree.feature_importances_ for tree in forest.estimators_],
             axis=0)
indices = np.argsort(importances)[::-1]

# Print the feature ranking
print("Top Feature ranking:")

for f in range(X.shape[1]):
    print("%d. feature %d (%f)" % (f + 1, indices[f], importances[indices[f]]))

##split

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.30,random_state=123)
sc=mm.StandardScaler()
X_train=sc.fit_transform(X_train)
X_test=sc.fit_transform(X_test)


##Decision Tree classifier
from sklearn import tree
clf = tree.DecisionTreeClassifier()
clf = clf.fit(X_train,y_train)
y_pred_dtc=clf.predict(X_test)
y_pred=pd.DataFrame(y_pred_dtc)
y_pred.columns = ['y_pred']
print('Accuracy before dimension reduction is: ')
print(accuracy_score(y_pred,y_test))


####After dimension Reduction
X_train_new=X_train[:,1:3]
X_test_new=X_test[:,1:3]

clf = clf.fit(X_train_new,y_train)
y_pred_dtc=clf.predict(X_test_new)
y_pred=pd.DataFrame(y_pred_dtc)
y_pred.columns = ['y_pred']
print('Accuracy after dimension reduction is: ')
print(accuracy_score(y_pred,y_test))