from sklearn.preprocessing import MinMaxScaler
import scipy.io
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

mat = scipy.io.loadmat('DataDNA.mat',squeeze_me=True)
feature = mat['fea'] # array
label = mat['gnd'] # array

#Zscore Normalization
zscore=stats.zscore(feature)
df_zscore = pd.DataFrame(data=zscore)
des_zscore=df_zscore.describe()

#Min-Max Normalization of Data
scaler = MinMaxScaler()
minmax=scaler.fit_transform(feature)
df_minmax = pd.DataFrame(data=minmax)
des_minmax=df_minmax.describe()

#Distribution of dataset
df_label= pd.DataFrame(data=label)
df_label.columns=['label']
plt.hist(label, bins='auto') 
plt.show()

count=df_label.label.value_counts()












