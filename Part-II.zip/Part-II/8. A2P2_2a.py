import scipy.io
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier

#Import Data
mat = scipy.io.loadmat('DataDNA.mat',squeeze_me=True)

feature = mat['fea'] # array
feature=stats.zscore(feature)#Normalized Data
label = mat['gnd'] # array

##spliting into test and train set
from sklearn.cross_validation import train_test_split
X_train,X_test,y_train,y_test=train_test_split(feature,label,test_size=0.30,random_state=42)

#K-NN
j=[]
s=[]
for i in range(1, 33, 2):
    j.append(i)   
    knn = KNeighborsClassifier(n_neighbors=i)
    scores = cross_val_score(knn, X_train, y_train, cv=5)
    s.append(scores.mean())

max_index=np.argmax(s)
print('Optimum no of neighbors',j[max_index])
plt.plot(j,s)
plt.ylabel('Classification Accuracy')
plt.xlabel('no. of neighbors (k)')
plt.grid()



