from sklearn.preprocessing import MinMaxScaler
import numpy as np
import scipy.io
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.model_selection import cross_val_score
from scipy import interp
from sklearn.cross_validation import KFold
from sklearn.metrics import roc_curve
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

#Import Data
mat = scipy.io.loadmat('DataDNA.mat',squeeze_me=True)
feature = mat['fea'] # array
feature=stats.zscore(feature)#Z-Score Normalized Data
label = mat['gnd'] # array

#Normalization of Data

zscore=stats.zscore(feature)
scaler = MinMaxScaler()
minmax=scaler.fit_transform(feature)

##spliting into test and train set
from sklearn.cross_validation import train_test_split
X_train,X_test,y_train,y_test=train_test_split(zscore,label,test_size=0.30,random_state=42)

s1=np.zeros((8,8))
from sklearn.svm import SVC

a=[0.1, 0.5, 1, 2, 5, 10, 20, 50]
g=[5000,200,50,2,.5,.125,.02,.005]

for i in range(0, 8, 1):
    for j in range(0, 8, 1):
        clf = SVC(C=a[i],gamma=g[j], kernel='rbf')
        scores1 = cross_val_score(clf, X_train, y_train, cv=5)
        s1[i,j]=scores1.mean()
               
X=X_train
y=y_train

kf = KFold(n=len(y), n_folds=5)

tprs = []
base_fpr = np.linspace(0, 1, 101)

plt.figure(figsize=(5, 5))
predictor = SVC(kernel='linear', C=5, gamma=0.02,probability=True, random_state=12345)
for i, (train, test) in enumerate(kf):
    
    model = predictor.fit(X[train], y[train])
    y_score = model.predict_proba(X[test])
    fpr, tpr, _ = roc_curve(y[test], y_score[:, 1])

    plt.plot(fpr, tpr, 'b', alpha=0.15)
    tpr = interp(base_fpr, fpr, tpr)
    tpr[0] = 0.0
    tprs.append(tpr)

tprs = np.array(tprs)
mean_tprs = tprs.mean(axis=0)
std = tprs.std(axis=0)

tprs_upper = np.minimum(mean_tprs + std, 1)
tprs_lower = mean_tprs - std


plt.plot(base_fpr, mean_tprs, 'b')
plt.fill_between(base_fpr, tprs_lower, tprs_upper, color='grey', alpha=0.3)

plt.plot([0, 1], [0, 1],'r--')
plt.xlim([-0.01, 1.01])
plt.ylim([-0.01, 1.01])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.axes().set_aspect('equal', 'datalim')
plt.show()





















